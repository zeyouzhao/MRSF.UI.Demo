﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MRSF.UI.Demo
{
    public partial class Form2 : MRSF.UI.DockBase
    {
        HardwareHandler Hh = new HardwareHandler();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.label1.Text = Hh.CpuInfo().CPUSN.ToString();
            this.label2.Text = Hh.MainBoardInfo().MainBoardSN.ToString();
            this.label3.Text=Hh.NetworkInfo().IPAddress.ToString();
            this.label4.Text=Hh.DiskDriveInfo().DiskDriveSN.ToString();
        }
    }
}
