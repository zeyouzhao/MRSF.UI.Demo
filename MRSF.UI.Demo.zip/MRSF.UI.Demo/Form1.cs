﻿using MRIT.Controls.WinFormsUI.Docking;
using MRSF.UI;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MRSF.UI.Demo
{
    public partial class Form1 : MRSF.UI.BaseForm
    {

        
        public Form1()
        {
            InitializeComponent();
        }

        #region 需要调用的函数

        
 [RemarkAttribute("WDHT")] //WDHT
        private void WDHT() { Form3 form3 = new Form3(); form3.Show(dockPanel); }

        [RemarkAttribute("JSJXX")] //JSJXX
        private void JSJXX() { Form2 form2 = new Form2();form2.Show(dockPanel); }
        
        [RemarkAttribute("New_Project")] //新建项目
        private void New_Project() { MessageBox.Show("新建项目"); }
        [RemarkAttribute("New_Doctment")] //新建项目
        private void New_Doctment() { MRSF.UI.DummyDoc dummyDoc = new MRSF.UI.DummyDoc(); dummyDoc.Show(dockPanel); }

        [RemarkAttribute("FormNormal")] //窗口大小：普通
        private void ChangeSizeToNrm() { this.WindowState = FormWindowState.Normal; }
        [RemarkAttribute("FormMinimize")] //窗口大小：最小化
        private void ChangeSizeToMin() { this.WindowState = FormWindowState.Minimized; }
        [RemarkAttribute("FormMaximize")] //窗口大小：最大化
        private void ChangeSizeToMax() { this.WindowState = FormWindowState.Maximized; }

        [RemarkAttribute("menuItemClose")] //关闭当前窗口
        private void menuItemClose()
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
                ActiveMdiChild.Close();
            else if (dockPanel.ActiveDocument != null)
                dockPanel.ActiveDocument.DockHandler.Close();
        }

        [RemarkAttribute("menuItemCloseAll")] //关闭所有窗口
        private void menuItemCloseAll()
        {
            CloseAllDocuments();
        }
        [RemarkAttribute("menuItemCloseAllButThisOne")] //关闭其他窗口
        private void menuItemCloseAllButThisOne()
        {

            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                Form activeMdi = ActiveMdiChild;
                foreach (Form form in MdiChildren)
                {
                    if (form != activeMdi)
                        form.Close();
                }
            }
            else
            {
                foreach (IDockContent document in dockPanel.DocumentsToArray())
                {
                    if (!document.DockHandler.IsActivated)
                        document.DockHandler.Close();
                }
            }
        }
      

        [RemarkAttribute("menuItemExit")] //退出程序
        private void menuItemExit() { Application.Exit(); }

        [RemarkAttribute("exitWithoutSavingLayout")] //退出程序
        private void exitWithoutSavingLayout()
        {
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.config");           
            if (File.Exists(configFile))
                File.Delete(configFile);
            Close();
        }


        [RemarkAttribute("FormAbout")] //关于程序
        private void AboutForm() { MRSF.UI.UserHelper about = new MRSF.UI.UserHelper(1); about.ShowDialog(); }
        
        [RemarkAttribute("UpLoadMRSFUI")] //检查更新
        private void UpLoadMRSFUI() { MRSF.UI.ClassLib.GlobalClass.AutoUpdate(); }

        [RemarkAttribute("OutputWindow")] //输出窗口
        private void OutputWindow()
        {

            if (FindTab("输出窗口") == null)
            {
                DummyOutputWindow dummyOutput = new DummyOutputWindow();
                dummyOutput.Text = "输出窗口";
                dummyOutput.Show(dockPanel, DockState.DockBottom);
            }
            else
            {
                FindTab("输出窗口").DockHandler.Show();

            }
            SetMenuItemCheck("输出窗口", mainMenu);


        }

        [RemarkAttribute("MenuBar")]
        private void MenuBar()
        {
            mainMenu.Visible = !mainMenu.Visible;
        }
        [RemarkAttribute("FileExplore")]//资源管理器
        private void FileExplore()
        { 
            MRSF.UI.DummySolutionExplorer dummySolutionExplorer = new MRSF.UI.DummySolutionExplorer();
            dummySolutionExplorer.Show(dockPanel);
        }
        [RemarkAttribute("menuItemNewWindow")]//新窗口
        private void menuItemNewWindow()
        {
            BaseForm newWindow = new BaseForm();
            newWindow.Text = newWindow.Text + " - New";
            newWindow.Show();
        }

        [RemarkAttribute("DocumentStyle_MDI")]//MDI文档样式
        private void DocumentStyle_MDI()
        {
            SetDocumentStyle("MDI");
        }

        [RemarkAttribute("DocumentStyle_SDI")]//SDI文档样式
        private void DocumentStyle_SDI()
        {
            SetDocumentStyle("SDI");
        }
        [RemarkAttribute("DocumentStyle_WINDOWS")]//WINDOWS文档样式
        private void DocumentStyle_WINDOWS()
        {
            SetDocumentStyle("WINDOWS");
        }
        [RemarkAttribute("DocumentStyle_SystemMDI")]//SystemMDI文档样式
        private void DocumentStyle_SystemMDI()
        {
            SetDocumentStyle("SystemMDI");
        }

        [RemarkAttribute("StatusBar")]//状态栏
        private void StatusBar()
        {
            statusBar.Visible = !statusBar.Visible;
        }
        


        private void SetDocumentStyle(string MenuText)
        {
            DocumentStyle oldStyle = dockPanel.DocumentStyle;
            DocumentStyle newStyle= dockPanel.DocumentStyle; 
            switch (MenuText)
            {
                case "MDI":
                    newStyle = DocumentStyle.DockingMdi;
                    break;
                case "SDI":
                    newStyle = DocumentStyle.DockingSdi;
                    break;
                case "WINDOWS":
                    newStyle = DocumentStyle.DockingWindow;
                    break;
                case "SystemMDI":
                    newStyle = DocumentStyle.SystemMdi;
                    break;
            }
           
            if (oldStyle == newStyle)
                return;

            if (oldStyle == DocumentStyle.SystemMdi || newStyle == DocumentStyle.SystemMdi)
                CloseAllDocuments();

            dockPanel.DocumentStyle = newStyle;
            SetMenuItemCheck(mainMenu.Items,"MDI", (newStyle == DocumentStyle.DockingMdi));
            SetMenuItemCheck(mainMenu.Items, "SDI", (newStyle == DocumentStyle.DockingSdi));
            SetMenuItemCheck(mainMenu.Items, "WINDOWS", (newStyle == DocumentStyle.DockingWindow));
            SetMenuItemCheck(mainMenu.Items, "SystemMDI", (newStyle == DocumentStyle.SystemMdi));

        }
        #endregion
    }
    }
